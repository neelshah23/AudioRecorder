import React from 'react';
import './App.css';
import MicRecorder from 'mic-recorder-to-mp3';

const Mp3Recorder = new MicRecorder({ bitRate: 128 });

class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      isRecording: false,
      blobURL: '',
      isBlocked: false,
      isPaused: true,
    };
  }

  start = () => {
    if (!this.state.isBlocked) {
      Mp3Recorder
        .start()
        .then(() => {
          this.setState({ isRecording: true });
          this.setState({ isPaused: false });
        }).catch((e) => console.error(e));
    }
  };

  pause = () => {
    Mp3Recorder
    .pause()
    .then(() => {
    this.setState({isRecording:false})
    this.setState({isPaused:true})
    }).catch((e) => console.log(e));
  }

  stop = () => {
    Mp3Recorder
      .stop()
      .getMp3()
      .then(([buffer, blob]) => {
        const blobURL = URL.createObjectURL(blob)
        this.setState({ blobURL, isRecording: false });
        this.setState({ blobURL, isPaused: true });
        const li = document.createElement('li');
        const player = new Audio(URL.createObjectURL(blob));
        player.controls = true;
        li.appendChild(player);
        document.querySelector('#playlist').appendChild(li);
      }).catch((e) => console.log(e)); 
  };

  render(){
    return (
        <header className="App-header">
          <div className="spacing-content"><button onClick={this.start} disabled={this.state.isRecording}>Record</button></div>
          <div className="spacing-content"><button onClick={this.pause} disabled={this.state.isPaused}>Pause</button></div>
          <div className="spacing-content"><button onClick={this.stop} disabled={!this.state.isRecording}>Stop</button></div>
          <p className="recording-text">Recorded Audio can be found below:</p>
          <ul id="playlist"></ul>
        </header>
    );
  }
}

export default App;
